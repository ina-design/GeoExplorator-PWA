# GeoExplorator-PWA

GeoExplorator-PWA este o aplicație web progresivă (PWA) pentru explorarea elementelor geografice, proiectată pentru a funcționa offline și pe dispozitive mobile.

## Cum să folosești acest repository

1. Clonează repository-ul sau descarcă-l local.
2. Încarcă fișierele aplicației:
   - `index.html`
   - `manifest.json`
   - `service-worker.js`
   - `icon-192.png`
   - `icon-512.png`

## Instalare rapidă

Deschide pagina principală (`index.html`) într-un browser compatibil cu PWA.

## Funcționalități

- Suport offline prin Service Worker
- Instalabil pe mobil și desktop
- Design adaptat pentru dispozitive mobile

---

> Acest fișier README poate fi extins pe măsură ce aplicația evoluează!